# AI Bildeverksted – Android v0.2

Android-app for AI-basert bildeforbedring og bildeendring med tekstinstruksjoner. Du velger eller tar et bilde, beskriver endringen på norsk, og kan eventuelt male over akkurat området som skal redigeres.

## Dette er nytt i v0.2

- Velg bilde fra Android Photo Picker
- Ta nytt bilde med kamera
- Pensel/maske direkte over bildet
- Viskelær, angre og tøm markering
- AI-redigering av hele bildet eller kun markert område
- Ekte før/etter-visning med slider
- Valgfritt referansebilde
- Kvalitet: Medium / High / Max
- Transparent bakgrunn
- Hurtigvalg for auto-forbedring, skarphet, objektfjerning og bakgrunn
- Fortsett redigering fra forrige AI-resultat
- Historikk for de 8 siste resultatene i samme økt
- Lagre direkte i Galleri
- Del resultat via Androids delingsmeny
- Serverstatus-test i appen
- Backend med skjult OpenAI API-nøkkel
- Valgfritt `APP_ACCESS_TOKEN`
- Filtype-/størrelseskontroll, rate-limit og request-timeout på backend
- GitHub Actions som kjører Android lint og bygger debug-APK

## Arkitektur

- `app/` – Android-app skrevet i Kotlin + Jetpack Compose
- `backend/` – Node.js/Express-proxy som kommuniserer med OpenAI
- `.github/workflows/build-apk.yml` – bygger APK i GitHub Actions
- `codemagic.yaml` – bygger installerbar APK i Codemagic

OpenAI-nøkkelen skal **aldri** ligge i Android-koden eller APK-en. Appen sender bildet til din backend, og backend sender det videre til OpenAI.

## 1. Start backend

Krever Node.js 20 eller nyere.

```bash
cd backend
cp .env.example .env
npm install
```

Rediger `.env`:

```env
OPENAI_API_KEY=sk-din-openai-nokkel
OPENAI_IMAGE_MODEL=gpt-image-2.5-sunburst
APP_ACCESS_TOKEN=lag-et-langt-tilfeldig-token
RATE_LIMIT_PER_MINUTE=12
TRUST_PROXY=0
PORT=3000
```

`APP_ACCESS_TOKEN` er valgfritt. Hvis det står tomt, kreves ikke token fra Android-appen.

Start:

```bash
npm start
```

Test lokalt:

```text
http://localhost:3000/health
```

For vanlig mobilbruk bør serveren eksponeres via **HTTPS**.

## 2. Android

Åpne rotmappen i Android Studio.

Prosjektet bruker:

- Android Gradle Plugin 9.4.0
- Gradle 9.6.0 i GitHub Actions
- JDK 17
- `compileSdk 37`
- `targetSdk 37`
- `minSdk 29`
- Jetpack Compose BOM `2026.09.00`

Bygg og installer appen. Åpne **Innstillinger / AI-server** og skriv inn serveradressen, f.eks.:

```text
https://bilde-api.dittdomene.no
```

Hvis du bruker `APP_ACCESS_TOKEN` på backend, skriv samme token i appen.

### Lokal testing på Wi-Fi

Du kan bruke PC-ens LAN-adresse, for eksempel:

```text
http://192.168.1.50:3000
```

`usesCleartextTraffic=true` er beholdt for lokal HTTP-testing. For en ren produksjonsvariant med bare HTTPS bør dette settes til `false` i `AndroidManifest.xml`.

## 3. Slik bruker du masken

1. Velg et bilde.
2. Aktiver **Marker område**.
3. Mal rødt over delen som skal endres.
4. Bruk **Viskelær** hvis du markerer for mye.
5. Skriv hva AI skal gjøre.
6. Trykk **Rediger markert område**.

Masken lages i samme størrelse som arbeidsbildet, med alfakanal. Det markerte området gjøres transparent i masken, mens resten bevares.

## 4. Referansebilde

Trykk **Legg til referanse** hvis du vil vise AI hvordan noe skal se ut, for eksempel en bestemt felg, farge, spoiler eller interiørdetalj. Kildebildet sendes først, referansebildet sendes som ekstra bilde.

## 5. GitHub – bygg APK automatisk

1. Opprett et GitHub-repository.
2. Last opp hele prosjektmappen.
3. Gå til **Actions → Build Android APK**.
4. Kjør workflowen.
5. Last ned artifact: `AI-Bildeverksted-v0.2-debug-apk`.

Workflowen kjører først Android lint og JavaScript-syntakssjekk, deretter bygges `app-debug.apk`.

## Viktig om kostnad

`high` og særlig `max` gir mer detalj, men bruker mer tid og kan koste mer enn `medium`. Bruk `medium` til raske prøver og `high`/`max` når du skal lagre sluttresultatet.

## Produksjon

Før offentlig publisering anbefales i tillegg:

- HTTPS-only
- ekte brukerinnlogging/autentisering
- server-side kvoter per bruker
- database for historikk hvis den skal overleve apprestart
- Play Integrity / App Check-lignende beskyttelse hvis API-et blir offentlig
- release-signering og Play Store App Bundle (`.aab`)

## 6. Codemagic – bygg APK fra codemagic.io/builds

Prosjektet inneholder nå `codemagic.yaml` i rotmappen. Dette er filen Codemagic leser automatisk.

### Første oppsett

1. Last hele prosjektet opp til et GitHub-, GitLab- eller Bitbucket-repository.
2. Logg inn på Codemagic og velg **Add application**.
3. Koble til repositoryet og legg til appen.
4. Kontroller at Codemagic finner `codemagic.yaml` i rotmappen.
5. Velg workflow **AI Bildeverksted - Android APK**.
6. Trykk **Start new build**.
7. Når bygget er ferdig, åpne **Artifacts** og last ned `app-debug.apk`.

### Hva Codemagic-oppsettet gjør

- bruker Java 17
- bruker Node LTS for syntakssjekk av backend
- laster ned og bruker Gradle 9.6.0 eksplisitt
- finner `sdkmanager` selv om den ikke ligger direkte i PATH
- godtar Android SDK-lisenser
- installerer `platforms;android-37`, `platform-tools` og `build-tools;36.0.0`
- skriver korrekt `local.properties` fra `$ANDROID_SDK_ROOT`
- kjører Android lint
- bygger `:app:assembleDebug`
- publiserer `app-debug.apk` som Codemagic-artifact

Det kreves ingen OpenAI API-nøkkel for å **bygge APK-en**. API-nøkkelen skal fortsatt kun ligge på backend-serveren når appen brukes.

### Ved build-feil

Åpne det røde steget i Codemagic-loggen. Workflowen er satt opp med `--stacktrace`, så Gradle-feilen vises detaljert. Hvis Android SDK-verktøyet ikke finnes, skriver workflowen ut hvor Codemagic faktisk har SDK-filene i stedet for bare å stoppe med `sdkmanager not found`.
