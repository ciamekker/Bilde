import "dotenv/config";
import crypto from "node:crypto";
import express from "express";
import multer from "multer";

const app = express();
app.disable("x-powered-by");
if (process.env.TRUST_PROXY === "1") app.set("trust proxy", 1);

const MAX_FILE_BYTES = 30 * 1024 * 1024;
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_BYTES, files: 3, fields: 8 },
  fileFilter: (_req, file, cb) => {
    const allowed = new Set(["image/png", "image/jpeg", "image/webp"]);
    cb(allowed.has(file.mimetype) ? null : new Error(`Ugyldig bildefil: ${file.mimetype}`), allowed.has(file.mimetype));
  },
});

// Enkel minnebasert beskyttelse mot feilkonfigurerte/offentlige klienter.
const hits = new Map();
function rateLimit(req, res, next) {
  const now = Date.now();
  const windowMs = 60_000;
  const max = Number(process.env.RATE_LIMIT_PER_MINUTE || 12);
  const key = req.ip || req.socket.remoteAddress || "unknown";
  const prev = hits.get(key);
  const entry = !prev || now - prev.start >= windowMs ? { start: now, count: 0 } : prev;
  entry.count += 1;
  hits.set(key, entry);
  if (entry.count > max) return res.status(429).json({ error: "For mange forespørsler. Prøv igjen om litt." });
  next();
}

function secureHeaders(_req, res, next) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Cache-Control", "no-store");
  next();
}

function auth(req, res, next) {
  const expected = process.env.APP_ACCESS_TOKEN || "";
  if (!expected) return next();
  const supplied = String(req.get("X-App-Token") || "");
  const a = Buffer.from(supplied);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "Ugyldig app-token" });
  }
  next();
}

app.use(secureHeaders);
app.use(rateLimit);
app.use(auth);

app.get("/health", (_req, res) => {
  res.json({
    ok: true,
    model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-sunburst",
    protected: Boolean(process.env.APP_ACCESS_TOKEN),
  });
});

app.post(
  "/edit",
  upload.fields([
    { name: "image", maxCount: 1 },
    { name: "reference", maxCount: 1 },
    { name: "mask", maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({ error: "OPENAI_API_KEY mangler på serveren" });
      }

      const files = req.files || {};
      const source = files.image?.[0];
      const reference = files.reference?.[0];
      const mask = files.mask?.[0];
      if (!source) return res.status(400).json({ error: "image mangler" });

      const prompt = String(req.body.prompt || "").trim();
      if (!prompt) return res.status(400).json({ error: "prompt mangler" });
      if (prompt.length > 12_000) return res.status(400).json({ error: "prompt er for lang" });

      const allowedQuality = new Set(["low", "medium", "high", "xhigh", "max", "auto"]);
      const quality = allowedQuality.has(req.body.quality) ? req.body.quality : "high";
      const allowedBackground = new Set(["auto", "transparent", "opaque"]);
      const background = allowedBackground.has(req.body.background) ? req.body.background : "auto";
      const model = process.env.OPENAI_IMAGE_MODEL || "gpt-image-2.5-sunburst";

      const form = new FormData();
      form.append("model", model);
      form.append("prompt", prompt);
      form.append("quality", quality);
      form.append("size", "auto");
      form.append("output_format", "png");
      form.append("background", background);
      form.append(
        "image[]",
        new Blob([source.buffer], { type: source.mimetype || "image/png" }),
        source.originalname || "source.png",
      );
      if (reference) {
        form.append(
          "image[]",
          new Blob([reference.buffer], { type: reference.mimetype || "image/png" }),
          reference.originalname || "reference.png",
        );
      }
      if (mask) {
        form.append(
          "mask",
          new Blob([mask.buffer], { type: "image/png" }),
          "mask.png",
        );
      }

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 290_000);
      let response;
      try {
        response = await fetch("https://api.openai.com/v1/images/edits", {
          method: "POST",
          headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
          body: form,
          signal: controller.signal,
        });
      } finally {
        clearTimeout(timeout);
      }

      const requestId = response.headers.get("x-request-id") || undefined;
      const json = await response.json();
      if (!response.ok) {
        console.error("OpenAI image edit failed", { requestId, status: response.status, error: json?.error });
        return res.status(response.status).json({
          error: json?.error?.message || "OpenAI image edit failed",
          requestId,
        });
      }

      const b64 = json?.data?.[0]?.b64_json;
      if (!b64) return res.status(502).json({ error: "AI returnerte ikke et bilde", requestId });

      const image = Buffer.from(b64, "base64");
      res.setHeader("Content-Type", "image/png");
      if (requestId) res.setHeader("X-OpenAI-Request-Id", requestId);
      return res.send(image);
    } catch (error) {
      if (error?.name === "AbortError") return res.status(504).json({ error: "AI-forespørselen tok for lang tid" });
      console.error(error);
      return res.status(500).json({ error: error?.message || "Ukjent serverfeil" });
    }
  },
);

app.use((error, _req, res, _next) => {
  console.error(error);
  if (error instanceof multer.MulterError) {
    return res.status(400).json({ error: `Opplastingsfeil: ${error.message}` });
  }
  return res.status(400).json({ error: error?.message || "Ugyldig forespørsel" });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => {
  console.log(`AI Bildeverksted API kjører på port ${port}`);
});
