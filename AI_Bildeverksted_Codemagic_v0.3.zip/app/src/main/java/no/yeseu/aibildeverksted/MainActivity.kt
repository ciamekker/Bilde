package no.yeseu.aibildeverksted

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlin.math.min

private data class NormalizedPoint(val x: Float, val y: Float)
private data class MaskStroke(
    val points: List<NormalizedPoint>,
    val widthRatio: Float,
    val erasing: Boolean,
)
private data class FitRect(val left: Float, val top: Float, val width: Float, val height: Float)
private data class HistoryItem(val bitmap: Bitmap, val bytes: ByteArray, val prompt: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                EditorScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditorScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("ai_bildeverksted", Context.MODE_PRIVATE) }

    var baseBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var resultBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var resultBytes by remember { mutableStateOf<ByteArray?>(null) }
    var referenceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var prompt by remember { mutableStateOf("") }
    var backendUrl by remember { mutableStateOf(prefs.getString("backend_url", "https://DIN-SERVER.example.com") ?: "") }
    var appToken by remember { mutableStateOf(prefs.getString("app_token", "") ?: "") }
    var quality by remember { mutableStateOf("high") }
    var transparentBackground by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Velg eller ta et bilde for å starte") }
    var selectedView by remember { mutableStateOf(0) }
    var compare by remember { mutableFloatStateOf(0.5f) }
    var brushRatio by remember { mutableFloatStateOf(0.07f) }
    var eraser by remember { mutableStateOf(false) }
    var maskMode by remember { mutableStateOf(false) }
    var strokes by remember { mutableStateOf<List<MaskStroke>>(emptyList()) }
    var activeStroke by remember { mutableStateOf<MaskStroke?>(null) }
    var history by remember { mutableStateOf<List<HistoryItem>>(emptyList()) }
    var settingsOpen by remember { mutableStateOf(false) }
    var pendingCameraUri by remember { mutableStateOf<Uri?>(null) }

    fun loadIntoEditor(uri: Uri) {
        scope.launch {
            loading = true
            status = "Leser bildet …"
            try {
                baseBitmap = loadBitmap(context, uri, 2560)
                resultBitmap = null
                resultBytes = null
                strokes = emptyList()
                activeStroke = null
                history = emptyList()
                selectedView = 0
                status = "Bilde klart"
            } catch (e: Exception) {
                status = "Kunne ikke lese bildet: ${e.message ?: "ukjent feil"}"
            } finally {
                loading = false
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadIntoEditor(uri)
    }

    val referencePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                referenceBitmap = runCatching { loadBitmap(context, uri, 2048) }.getOrNull()
                status = if (referenceBitmap != null) "Referansebilde lagt til" else "Kunne ikke lese referansebildet"
            }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = pendingCameraUri
        if (ok && uri != null) loadIntoEditor(uri) else status = "Kamera avbrutt"
    }

    suspend fun runEdit(instruction: String) {
        val source = baseBitmap
        if (source == null) {
            status = "Velg et bilde først"
            return
        }
        if (backendUrl.contains("DIN-SERVER") || backendUrl.isBlank()) {
            status = "Legg inn adressen til AI-serveren under Innstillinger først"
            settingsOpen = true
            return
        }
        if (instruction.isBlank()) {
            status = "Skriv hva du vil gjøre med bildet"
            return
        }

        loading = true
        status = if (strokes.isNotEmpty()) "AI redigerer markert område …" else "AI redigerer bildet …"
        try {
            val sourceBytes = withContext(Dispatchers.Default) { bitmapToPng(source) }
            val refBytes = referenceBitmap?.let { withContext(Dispatchers.Default) { bitmapToPng(it) } }
            val maskBytes = if (strokes.isNotEmpty()) {
                withContext(Dispatchers.Default) { createMaskPng(source.width, source.height, strokes) }
            } else null

            val finalPrompt = buildEditPrompt(instruction, maskBytes != null, referenceBitmap != null)
            val bytes = withContext(Dispatchers.IO) {
                editImage(
                    backendUrl = backendUrl,
                    appToken = appToken,
                    imageBytes = sourceBytes,
                    referenceBytes = refBytes,
                    maskBytes = maskBytes,
                    prompt = finalPrompt,
                    quality = quality,
                    transparentBackground = transparentBackground,
                )
            }
            val decoded = withContext(Dispatchers.Default) {
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: error("AI returnerte et ugyldig bilde")
            }
            resultBytes = bytes
            resultBitmap = decoded
            history = (listOf(HistoryItem(decoded, bytes, instruction)) + history).take(8)
            selectedView = 1
            maskMode = false
            status = "Ferdig – resultatet er klart"
        } catch (e: Exception) {
            status = "Feil: ${e.message ?: "ukjent feil"}"
        } finally {
            loading = false
        }
    }

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("AI Bildeverksted", fontSize = 28.sp)
            Text(
                "Forbedre hele bildet eller marker nøyaktig det området du vil endre.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PhotoLibrary, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Galleri")
                }
                OutlinedButton(
                    onClick = {
                        runCatching { createCameraUri(context) }
                            .onSuccess {
                                pendingCameraUri = it
                                cameraLauncher.launch(it)
                            }
                            .onFailure { status = "Kunne ikke starte kamera: ${it.message}" }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.AddAPhoto, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Kamera")
                }
            }

            val base = baseBitmap
            if (base != null) {
                ImageEditorSurface(
                    baseBitmap = base,
                    resultBitmap = resultBitmap,
                    selectedView = selectedView,
                    compare = compare,
                    maskMode = maskMode,
                    eraser = eraser,
                    brushRatio = brushRatio,
                    strokes = strokes,
                    activeStroke = activeStroke,
                    onActiveStrokeChange = { activeStroke = it },
                    onStrokeCommitted = {
                        strokes = strokes + it
                        activeStroke = null
                    }
                )

                if (resultBitmap != null) {
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        listOf("Original", "Resultat", "Før/etter").forEachIndexed { index, label ->
                            SegmentedButton(
                                selected = selectedView == index,
                                onClick = { selectedView = index },
                                shape = SegmentedButtonDefaults.itemShape(index, 3)
                            ) { Text(label) }
                        }
                    }
                    if (selectedView == 2) {
                        Text("Før/etter: ${(compare * 100).toInt()} %")
                        Slider(value = compare, onValueChange = { compare = it })
                    }
                }

                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Brush, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Marker område", modifier = Modifier.weight(1f))
                            Switch(checked = maskMode, onCheckedChange = { maskMode = it })
                        }
                        if (maskMode) {
                            Text("Mal over området AI skal endre. Rødt = rediger dette området.")
                            Text("Penselstørrelse: ${(brushRatio * 100).toInt()} %")
                            Slider(
                                value = brushRatio,
                                onValueChange = { brushRatio = it },
                                valueRange = 0.015f..0.22f
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = !eraser,
                                    onClick = { eraser = false },
                                    label = { Text("Pensel") },
                                    leadingIcon = { Icon(Icons.Default.Brush, null) }
                                )
                                FilterChip(
                                    selected = eraser,
                                    onClick = { eraser = true },
                                    label = { Text("Viskelær") },
                                    leadingIcon = { Icon(Icons.Default.Clear, null) }
                                )
                                IconButton(
                                    onClick = { if (strokes.isNotEmpty()) strokes = strokes.dropLast(1) },
                                    enabled = strokes.isNotEmpty()
                                ) { Icon(Icons.Default.Undo, "Angre markering") }
                                IconButton(
                                    onClick = { strokes = emptyList() },
                                    enabled = strokes.isNotEmpty()
                                ) { Icon(Icons.Default.RestartAlt, "Tøm markering") }
                            }
                        }
                    }
                }
            }

            Text("Hurtigvalg")
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickChip("Auto-forbedre") {
                    prompt = "Forbedre bildet profesjonelt: mer naturlig skarphet og detaljer, bedre eksponering og dynamikk, mindre støy og kompresjonsartefakter. Bevar motiv, identitet, geometri, tekst og komposisjon. Ikke legg til nye objekter."
                }
                QuickChip("Skarpere") {
                    prompt = "Gjør bildet tydeligere og skarpere. Reduser støy, bevegelsesuskarphet og kompresjonsartefakter, men behold naturlige teksturer og alle objekter uendret."
                }
                QuickChip("Fjern objekt") {
                    prompt = "Fjern objektet jeg har markert og fyll området naturlig slik at bakgrunnen ser ekte og sammenhengende ut. Ikke endre resten av bildet."
                    maskMode = true
                }
                QuickChip("Bytt bakgrunn") {
                    prompt = "Bytt bakgrunnen slik jeg beskriver, men behold hovedmotivet, proporsjoner, identitet, klær, kjøretøy og detaljer uendret."
                }
                QuickChip("Transparent") {
                    prompt = "Fjern bakgrunnen nøyaktig rundt hovedmotivet. Bevar fine kanter, hår og små detaljer."
                    transparentBackground = true
                }
            }

            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text("Beskriv endringen") },
                placeholder = { Text("F.eks. senk bilen 30 mm, behold felgene og gjør skjermbreddingen diskré") },
                minLines = 4,
                modifier = Modifier.fillMaxWidth()
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Transparent bakgrunn", modifier = Modifier.weight(1f))
                Switch(checked = transparentBackground, onCheckedChange = { transparentBackground = it })
            }

            Text("Kvalitet")
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                listOf("medium", "high", "max").forEachIndexed { index, item ->
                    SegmentedButton(
                        selected = quality == item,
                        onClick = { quality = item },
                        shape = SegmentedButtonDefaults.itemShape(index, 3)
                    ) { Text(item.replaceFirstChar { it.uppercase() }) }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { referencePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (referenceBitmap == null) "Legg til referanse" else "Bytt referanse")
                }
                if (referenceBitmap != null) {
                    OutlinedButton(onClick = { referenceBitmap = null }) { Text("Fjern") }
                }
            }
            if (referenceBitmap != null) {
                Text("Referansebildet brukes som ekstra visuell veiledning.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Button(
                onClick = { scope.launch { runEdit(prompt) } },
                enabled = !loading && baseBitmap != null && prompt.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (loading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                } else {
                    Icon(Icons.Default.AutoFixHigh, null)
                    Spacer(Modifier.width(8.dp))
                }
                Text(if (strokes.isNotEmpty()) "Rediger markert område" else "Utfør AI-redigering")
            }

            if (resultBytes != null && resultBitmap != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            scope.launch {
                                status = runCatching {
                                    saveToGallery(context, resultBytes!!)
                                    "Lagret i Galleri"
                                }.getOrElse { "Kunne ikke lagre: ${it.message}" }
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Download, null)
                        Spacer(Modifier.width(5.dp))
                        Text("Lagre")
                    }
                    OutlinedButton(
                        onClick = {
                            status = runCatching {
                                shareImage(context, resultBytes!!)
                                "Deling åpnet"
                            }.getOrElse { "Kunne ikke dele: ${it.message}" }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Share, null)
                        Spacer(Modifier.width(5.dp))
                        Text("Del")
                    }
                }
                OutlinedButton(
                    onClick = {
                        baseBitmap = resultBitmap
                        resultBitmap = null
                        resultBytes = null
                        strokes = emptyList()
                        selectedView = 0
                        status = "Resultatet er nå nytt utgangspunkt"
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Fortsett redigering fra resultatet")
                }
            }

            if (history.isNotEmpty()) {
                Text("Historikk")
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    history.forEachIndexed { index, item ->
                        OutlinedButton(
                            onClick = {
                                resultBitmap = item.bitmap
                                resultBytes = item.bytes
                                prompt = item.prompt
                                selectedView = 1
                                status = "Åpnet resultat ${index + 1} fra historikken"
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${index + 1}. ${item.prompt.take(70)}${if (item.prompt.length > 70) "…" else ""}")
                        }
                    }
                }
            }

            Text(status, color = MaterialTheme.colorScheme.primary)

            OutlinedButton(onClick = { settingsOpen = !settingsOpen }, modifier = Modifier.fillMaxWidth()) {
                Text(if (settingsOpen) "Skjul innstillinger" else "Innstillinger / AI-server")
            }
            if (settingsOpen) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = backendUrl,
                            onValueChange = {
                                backendUrl = it.trim()
                                prefs.edit().putString("backend_url", backendUrl).apply()
                            },
                            label = { Text("Serveradresse") },
                            supportingText = { Text("Eksempel: https://bilde-api.dittdomene.no") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = appToken,
                            onValueChange = {
                                appToken = it
                                prefs.edit().putString("app_token", appToken).apply()
                            },
                            label = { Text("App-token (valgfritt)") },
                            supportingText = { Text("Bruk samme verdi som APP_ACCESS_TOKEN på serveren") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    status = runCatching { testServer(backendUrl, appToken) }
                                        .fold({ "Server svarer: OK" }, { "Serverfeil: ${it.message}" })
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Test server") }
                        Text(
                            "OpenAI API-nøkkelen skal kun ligge på serveren – aldri i APK-en.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickChip(text: String, onClick: () -> Unit) {
    FilterChip(selected = false, onClick = onClick, label = { Text(text) })
}

@Composable
private fun ImageEditorSurface(
    baseBitmap: Bitmap,
    resultBitmap: Bitmap?,
    selectedView: Int,
    compare: Float,
    maskMode: Boolean,
    eraser: Boolean,
    brushRatio: Float,
    strokes: List<MaskStroke>,
    activeStroke: MaskStroke?,
    onActiveStrokeChange: (MaskStroke?) -> Unit,
    onStrokeCommitted: (MaskStroke) -> Unit,
) {
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    val baseImage = remember(baseBitmap) { baseBitmap.asImageBitmap() }
    val resultImage = remember(resultBitmap) { resultBitmap?.asImageBitmap() }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF111318))
            .onSizeChanged { canvasSize = it }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val rect = fitRect(IntSize(size.width.toInt(), size.height.toInt()), baseBitmap.width, baseBitmap.height)
            val dstOffset = IntOffset(rect.left.toInt(), rect.top.toInt())
            val dstSize = IntSize(rect.width.toInt().coerceAtLeast(1), rect.height.toInt().coerceAtLeast(1))

            fun drawBase() {
                drawImage(
                    image = baseImage,
                    srcOffset = IntOffset.Zero,
                    srcSize = IntSize(baseBitmap.width, baseBitmap.height),
                    dstOffset = dstOffset,
                    dstSize = dstSize,
                    filterQuality = FilterQuality.High
                )
            }

            fun drawResult() {
                val img = resultImage ?: return
                val rb = resultBitmap ?: return
                drawImage(
                    image = img,
                    srcOffset = IntOffset.Zero,
                    srcSize = IntSize(rb.width, rb.height),
                    dstOffset = dstOffset,
                    dstSize = dstSize,
                    filterQuality = FilterQuality.High
                )
            }

            when {
                selectedView == 1 && resultImage != null -> drawResult()
                selectedView == 2 && resultImage != null -> {
                    drawBase()
                    clipRect(
                        left = rect.left,
                        top = rect.top,
                        right = rect.left + rect.width * compare,
                        bottom = rect.top + rect.height
                    ) { drawResult() }
                    val x = rect.left + rect.width * compare
                    drawLine(Color.White, start = androidx.compose.ui.geometry.Offset(x, rect.top), end = androidx.compose.ui.geometry.Offset(x, rect.top + rect.height), strokeWidth = 3f)
                }
                else -> drawBase()
            }
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .then(
                    if (maskMode) {
                        Modifier.pointerInput(baseBitmap, eraser, brushRatio, canvasSize, strokes.size) {
                            var currentStroke: MaskStroke? = null
                            detectDragGestures(
                                onDragStart = { offset ->
                                    normalizedPoint(offset.x, offset.y, canvasSize, baseBitmap)?.let { p ->
                                        currentStroke = MaskStroke(listOf(p), brushRatio, eraser)
                                        onActiveStrokeChange(currentStroke)
                                    }
                                },
                                onDragEnd = {
                                    currentStroke?.let(onStrokeCommitted)
                                    currentStroke = null
                                    onActiveStrokeChange(null)
                                },
                                onDragCancel = {
                                    currentStroke = null
                                    onActiveStrokeChange(null)
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    normalizedPoint(change.position.x, change.position.y, canvasSize, baseBitmap)?.let { p ->
                                        currentStroke = currentStroke?.let { it.copy(points = it.points + p) }
                                        onActiveStrokeChange(currentStroke)
                                    }
                                }
                            )
                        }
                    } else Modifier
                )
        ) {
            if (!maskMode) return@Canvas
            val rect = fitRect(IntSize(size.width.toInt(), size.height.toInt()), baseBitmap.width, baseBitmap.height)
            (strokes + listOfNotNull(activeStroke)).forEach { stroke ->
                val width = stroke.widthRatio * min(rect.width, rect.height)
                val blend = if (stroke.erasing) BlendMode.Clear else BlendMode.SrcOver
                val color = Color(0x88FF3B30)
                val pts = stroke.points.map {
                    androidx.compose.ui.geometry.Offset(rect.left + it.x * rect.width, rect.top + it.y * rect.height)
                }
                pts.forEach { p -> drawCircle(color, radius = width / 2f, center = p, blendMode = blend) }
                pts.zipWithNext().forEach { (a, b) ->
                    drawLine(color, a, b, strokeWidth = width, cap = StrokeCap.Round, blendMode = blend)
                }
            }
        }
    }
}

private fun fitRect(canvas: IntSize, imageW: Int, imageH: Int): FitRect {
    if (canvas.width <= 0 || canvas.height <= 0 || imageW <= 0 || imageH <= 0) return FitRect(0f, 0f, 1f, 1f)
    val scale = min(canvas.width.toFloat() / imageW, canvas.height.toFloat() / imageH)
    val w = imageW * scale
    val h = imageH * scale
    return FitRect((canvas.width - w) / 2f, (canvas.height - h) / 2f, w, h)
}

private fun normalizedPoint(x: Float, y: Float, canvas: IntSize, bitmap: Bitmap): NormalizedPoint? {
    val rect = fitRect(canvas, bitmap.width, bitmap.height)
    if (x < rect.left || x > rect.left + rect.width || y < rect.top || y > rect.top + rect.height) return null
    return NormalizedPoint(
        ((x - rect.left) / rect.width).coerceIn(0f, 1f),
        ((y - rect.top) / rect.height).coerceIn(0f, 1f)
    )
}

private fun buildEditPrompt(instruction: String, hasMask: Boolean, hasReference: Boolean): String = buildString {
    append("Edit the supplied source image according to this user instruction: ")
    append(instruction.trim())
    append(". Preserve photographic realism, perspective, proportions, identity, recognizable objects, logos and text unless the instruction explicitly asks to change them.")
    if (hasMask) append(" Use the provided mask as guidance and make the requested change only in the marked region; preserve everything outside it as closely as possible.")
    if (hasReference) append(" The second image is a visual reference only; use relevant appearance/details from it without replacing unrelated parts of the source image.")
}

private suspend fun loadBitmap(context: Context, uri: Uri, maxEdge: Int): Bitmap = withContext(Dispatchers.IO) {
    val source = ImageDecoder.createSource(context.contentResolver, uri)
    ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
        val w = info.size.width
        val h = info.size.height
        if (w > maxEdge || h > maxEdge) {
            val scale = min(maxEdge.toFloat() / w, maxEdge.toFloat() / h)
            decoder.setTargetSize((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1))
        }
        decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
    }
}

private fun bitmapToPng(bitmap: Bitmap): ByteArray = ByteArrayOutputStream().use { out ->
    check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) { "Kunne ikke kode bildet" }
    out.toByteArray()
}

private fun createMaskPng(width: Int, height: Int, strokes: List<MaskStroke>): ByteArray {
    val mask = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(mask)
    canvas.drawColor(android.graphics.Color.WHITE)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    val minDim = min(width, height).toFloat()

    strokes.forEach { stroke ->
        val strokeWidth = (stroke.widthRatio * minDim).coerceAtLeast(2f)
        if (stroke.erasing) {
            paint.xfermode = null
            pointPaint.xfermode = null
            paint.color = android.graphics.Color.WHITE
            pointPaint.color = android.graphics.Color.WHITE
        } else {
            paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            pointPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        paint.strokeWidth = strokeWidth
        val pts = stroke.points.map { android.graphics.PointF(it.x * width, it.y * height) }
        pts.forEach { canvas.drawCircle(it.x, it.y, strokeWidth / 2f, pointPaint) }
        pts.zipWithNext().forEach { (a, b) -> canvas.drawLine(a.x, a.y, b.x, b.y, paint) }
    }

    paint.xfermode = null
    pointPaint.xfermode = null
    return bitmapToPng(mask).also { mask.recycle() }
}

private fun editImage(
    backendUrl: String,
    appToken: String,
    imageBytes: ByteArray,
    referenceBytes: ByteArray?,
    maskBytes: ByteArray?,
    prompt: String,
    quality: String,
    transparentBackground: Boolean,
): ByteArray {
    val boundary = "----AIBildeverksted${UUID.randomUUID()}"
    val connection = (URL(backendUrl.trimEnd('/') + "/edit").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        doOutput = true
        connectTimeout = 30_000
        readTimeout = 300_000
        setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        setRequestProperty("Accept", "image/png")
        if (appToken.isNotBlank()) setRequestProperty("X-App-Token", appToken)
    }

    BufferedOutputStream(connection.outputStream).use { out ->
        fun textField(name: String, value: String) {
            out.write("--$boundary\r\n".toByteArray())
            out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
            out.write(value.toByteArray(Charsets.UTF_8))
            out.write("\r\n".toByteArray())
        }
        fun fileField(name: String, filename: String, mime: String, bytes: ByteArray) {
            out.write("--$boundary\r\n".toByteArray())
            out.write("Content-Disposition: form-data; name=\"$name\"; filename=\"$filename\"\r\n".toByteArray())
            out.write("Content-Type: $mime\r\n\r\n".toByteArray())
            out.write(bytes)
            out.write("\r\n".toByteArray())
        }
        textField("prompt", prompt)
        textField("quality", quality)
        textField("background", if (transparentBackground) "transparent" else "auto")
        fileField("image", "source.png", "image/png", imageBytes)
        referenceBytes?.let { fileField("reference", "reference.png", "image/png", it) }
        maskBytes?.let { fileField("mask", "mask.png", "image/png", it) }
        out.write("--$boundary--\r\n".toByteArray())
    }

    val code = connection.responseCode
    val stream = if (code in 200..299) connection.inputStream else connection.errorStream
    val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
    if (code !in 200..299) {
        val msg = bytes.toString(Charsets.UTF_8).take(1000).ifBlank { "HTTP $code" }
        throw IllegalStateException(msg)
    }
    return bytes
}

private suspend fun testServer(backendUrl: String, appToken: String): Unit = withContext(Dispatchers.IO) {
    require(backendUrl.isNotBlank() && !backendUrl.contains("DIN-SERVER")) { "Serveradresse mangler" }
    val connection = (URL(backendUrl.trimEnd('/') + "/health").openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 10_000
        readTimeout = 10_000
        if (appToken.isNotBlank()) setRequestProperty("X-App-Token", appToken)
    }
    val code = connection.responseCode
    if (code !in 200..299) error("HTTP $code")
}

private suspend fun saveToGallery(context: Context, bytes: ByteArray) = withContext(Dispatchers.IO) {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "AI_Bildeverksted_${System.currentTimeMillis()}.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI Bildeverksted")
        put(MediaStore.Images.Media.IS_PENDING, 1)
    }
    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: error("Kunne ikke opprette fil i Galleri")
    try {
        context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            ?: error("Kunne ikke åpne bildefilen")
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        context.contentResolver.update(uri, values, null, null)
    } catch (e: Exception) {
        context.contentResolver.delete(uri, null, null)
        throw e
    }
}

private fun createCameraUri(context: Context): Uri {
    val dir = File(context.cacheDir, "camera").apply { mkdirs() }
    val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

private fun shareImage(context: Context, bytes: ByteArray) {
    val dir = File(context.cacheDir, "shared").apply { mkdirs() }
    val file = File(dir, "AI_Bildeverksted_${System.currentTimeMillis()}.png")
    file.writeBytes(bytes)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "image/png"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Del bilde"))
}
